﻿namespace interfaceMasterMindIG
{
    partial class Difficulty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.trackBarLenght = new System.Windows.Forms.TrackBar();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.trackBarColors = new System.Windows.Forms.TrackBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.validBtn = new System.Windows.Forms.Button();
            this.toolTipLength = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipColor = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.trackBarLenght)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarColors)).BeginInit();
            this.SuspendLayout();
            // 
            // trackBarLenght
            // 
            this.trackBarLenght.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.trackBarLenght.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.trackBarLenght.Cursor = System.Windows.Forms.Cursors.Hand;
            this.trackBarLenght.Location = new System.Drawing.Point(156, 64);
            this.trackBarLenght.Maximum = 5;
            this.trackBarLenght.Name = "trackBarLenght";
            this.trackBarLenght.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBarLenght.Size = new System.Drawing.Size(500, 45);
            this.trackBarLenght.TabIndex = 0;
            this.trackBarLenght.Tag = "";
            this.trackBarLenght.Value = 4;
            this.trackBarLenght.Scroll += new System.EventHandler(this.trackBarLenght_Scroll);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.trackBarLenght, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.trackBarColors, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.validBtn, 0, 6);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(812, 294);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // trackBarColors
            // 
            this.trackBarColors.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.trackBarColors.Cursor = System.Windows.Forms.Cursors.Hand;
            this.trackBarColors.Location = new System.Drawing.Point(156, 180);
            this.trackBarColors.Maximum = 5;
            this.trackBarColors.Name = "trackBarColors";
            this.trackBarColors.Size = new System.Drawing.Size(500, 45);
            this.trackBarColors.TabIndex = 0;
            this.trackBarColors.Value = 3;
            this.trackBarColors.Scroll += new System.EventHandler(this.trackBarColors_Scroll);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift Condensed", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(291, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(229, 39);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre de couleurs";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift Condensed", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(304, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "Longueur du code";
            // 
            // validBtn
            // 
            this.validBtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.validBtn.AutoSize = true;
            this.validBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.validBtn.Font = new System.Drawing.Font("Bahnschrift Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validBtn.Location = new System.Drawing.Point(700, 243);
            this.validBtn.Name = "validBtn";
            this.validBtn.Size = new System.Drawing.Size(109, 39);
            this.validBtn.TabIndex = 3;
            this.validBtn.Text = "Valider";
            this.validBtn.UseVisualStyleBackColor = true;
            this.validBtn.Click += new System.EventHandler(this.validBtn_Click);
            // 
            // Difficulty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(836, 318);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Difficulty";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.trackBarLenght)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarColors)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TrackBar trackBarLenght;
        private System.Windows.Forms.TrackBar trackBarColors;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button validBtn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ToolTip toolTipLength;
        private System.Windows.Forms.ToolTip toolTipColor;
    }
}