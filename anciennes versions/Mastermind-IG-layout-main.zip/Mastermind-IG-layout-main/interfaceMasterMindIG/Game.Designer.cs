﻿namespace mise_en_page_MM
{
    partial class Game
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game));
            this.panel1 = new System.Windows.Forms.Panel();
            this.colorPnl = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.menuBtn = new System.Windows.Forms.Button();
            this.undoBtn = new System.Windows.Forms.Button();
            this.resetBtn = new System.Windows.Forms.Button();
            this.validBtn = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.greenBtn = new System.Windows.Forms.Button();
            this.yellowBtn = new System.Windows.Forms.Button();
            this.whiteBtn = new System.Windows.Forms.Button();
            this.redBtn = new System.Windows.Forms.Button();
            this.blueBtn = new System.Windows.Forms.Button();
            this.magentaBtn = new System.Windows.Forms.Button();
            this.cyanBtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.colorPnl);
            this.panel1.Controls.Add(this.tableLayoutPanel3);
            this.panel1.Controls.Add(this.menuBtn);
            this.panel1.Controls.Add(this.undoBtn);
            this.panel1.Controls.Add(this.resetBtn);
            this.panel1.Controls.Add(this.validBtn);
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(477, 737);
            this.panel1.TabIndex = 0;
            // 
            // colorPnl
            // 
            this.colorPnl.ColumnCount = 4;
            this.colorPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.colorPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.colorPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.colorPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.colorPnl.Location = new System.Drawing.Point(27, 17);
            this.colorPnl.Name = "colorPnl";
            this.colorPnl.RowCount = 10;
            this.colorPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.colorPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.colorPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.colorPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.colorPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.colorPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.colorPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.colorPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.colorPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.colorPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.colorPnl.Size = new System.Drawing.Size(214, 600);
            this.colorPnl.TabIndex = 4;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.Location = new System.Drawing.Point(27, 654);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(192, 50);
            this.tableLayoutPanel3.TabIndex = 3;
            // 
            // menuBtn
            // 
            this.menuBtn.BackColor = System.Drawing.Color.Transparent;
            this.menuBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menuBtn.BackgroundImage")));
            this.menuBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menuBtn.FlatAppearance.BorderSize = 3;
            this.menuBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menuBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.menuBtn.Location = new System.Drawing.Point(372, 683);
            this.menuBtn.Name = "menuBtn";
            this.menuBtn.Size = new System.Drawing.Size(90, 40);
            this.menuBtn.TabIndex = 2;
            this.menuBtn.Text = "Menu";
            this.menuBtn.UseVisualStyleBackColor = false;
            // 
            // undoBtn
            // 
            this.undoBtn.BackColor = System.Drawing.Color.Transparent;
            this.undoBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("undoBtn.BackgroundImage")));
            this.undoBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.undoBtn.FlatAppearance.BorderSize = 3;
            this.undoBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.undoBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.undoBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.undoBtn.Location = new System.Drawing.Point(269, 683);
            this.undoBtn.Name = "undoBtn";
            this.undoBtn.Size = new System.Drawing.Size(90, 40);
            this.undoBtn.TabIndex = 2;
            this.undoBtn.Text = "Undo";
            this.undoBtn.UseVisualStyleBackColor = false;
            this.undoBtn.Click += new System.EventHandler(this.undoBtn_Click);
            // 
            // resetBtn
            // 
            this.resetBtn.BackColor = System.Drawing.Color.Transparent;
            this.resetBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("resetBtn.BackgroundImage")));
            this.resetBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.resetBtn.FlatAppearance.BorderSize = 3;
            this.resetBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.resetBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.resetBtn.Location = new System.Drawing.Point(372, 639);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(90, 40);
            this.resetBtn.TabIndex = 2;
            this.resetBtn.Text = "Reset";
            this.resetBtn.UseVisualStyleBackColor = false;
            // 
            // validBtn
            // 
            this.validBtn.BackColor = System.Drawing.Color.Transparent;
            this.validBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("validBtn.BackgroundImage")));
            this.validBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.validBtn.FlatAppearance.BorderSize = 3;
            this.validBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.validBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.validBtn.Location = new System.Drawing.Point(269, 639);
            this.validBtn.Name = "validBtn";
            this.validBtn.Size = new System.Drawing.Size(90, 40);
            this.validBtn.TabIndex = 2;
            this.validBtn.Text = "Valider";
            this.validBtn.UseVisualStyleBackColor = false;
            this.validBtn.Click += new System.EventHandler(this.validBtn_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.greenBtn, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.yellowBtn, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.whiteBtn, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.redBtn, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.blueBtn, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.magentaBtn, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.cyanBtn, 0, 6);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(393, 17);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(69, 422);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // greenBtn
            // 
            this.greenBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.greenBtn.BackgroundImage = global::mise_en_page_MM.Properties.Resources.green;
            this.greenBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.greenBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.greenBtn.FlatAppearance.BorderSize = 0;
            this.greenBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.greenBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.greenBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.greenBtn.Location = new System.Drawing.Point(14, 10);
            this.greenBtn.Name = "greenBtn";
            this.greenBtn.Size = new System.Drawing.Size(40, 40);
            this.greenBtn.TabIndex = 0;
            this.greenBtn.UseVisualStyleBackColor = true;
            this.greenBtn.Click += new System.EventHandler(this.Bouton_Click);
            this.greenBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseDown);
            this.greenBtn.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseUp);
            // 
            // yellowBtn
            // 
            this.yellowBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.yellowBtn.BackgroundImage = global::mise_en_page_MM.Properties.Resources.yellow;
            this.yellowBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.yellowBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.yellowBtn.FlatAppearance.BorderSize = 0;
            this.yellowBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.yellowBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.yellowBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.yellowBtn.Location = new System.Drawing.Point(14, 70);
            this.yellowBtn.Name = "yellowBtn";
            this.yellowBtn.Size = new System.Drawing.Size(40, 40);
            this.yellowBtn.TabIndex = 0;
            this.yellowBtn.UseVisualStyleBackColor = true;
            this.yellowBtn.Click += new System.EventHandler(this.Bouton_Click);
            this.yellowBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseDown);
            this.yellowBtn.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseUp);
            // 
            // whiteBtn
            // 
            this.whiteBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.whiteBtn.BackgroundImage = global::mise_en_page_MM.Properties.Resources.white;
            this.whiteBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.whiteBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.whiteBtn.FlatAppearance.BorderSize = 0;
            this.whiteBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.whiteBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.whiteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.whiteBtn.Location = new System.Drawing.Point(14, 130);
            this.whiteBtn.Name = "whiteBtn";
            this.whiteBtn.Size = new System.Drawing.Size(40, 40);
            this.whiteBtn.TabIndex = 0;
            this.whiteBtn.UseVisualStyleBackColor = true;
            this.whiteBtn.Click += new System.EventHandler(this.Bouton_Click);
            this.whiteBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseDown);
            this.whiteBtn.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseUp);
            // 
            // redBtn
            // 
            this.redBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.redBtn.BackgroundImage = global::mise_en_page_MM.Properties.Resources.red;
            this.redBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.redBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.redBtn.FlatAppearance.BorderSize = 0;
            this.redBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.redBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.redBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.redBtn.Location = new System.Drawing.Point(14, 190);
            this.redBtn.Name = "redBtn";
            this.redBtn.Size = new System.Drawing.Size(40, 40);
            this.redBtn.TabIndex = 0;
            this.redBtn.UseVisualStyleBackColor = true;
            this.redBtn.Click += new System.EventHandler(this.Bouton_Click);
            this.redBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseDown);
            this.redBtn.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseUp);
            // 
            // blueBtn
            // 
            this.blueBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.blueBtn.BackgroundImage = global::mise_en_page_MM.Properties.Resources.blue;
            this.blueBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.blueBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.blueBtn.FlatAppearance.BorderSize = 0;
            this.blueBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.blueBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.blueBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.blueBtn.Location = new System.Drawing.Point(14, 250);
            this.blueBtn.Name = "blueBtn";
            this.blueBtn.Size = new System.Drawing.Size(40, 40);
            this.blueBtn.TabIndex = 0;
            this.blueBtn.UseVisualStyleBackColor = true;
            this.blueBtn.Click += new System.EventHandler(this.Bouton_Click);
            this.blueBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseDown);
            this.blueBtn.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseUp);
            // 
            // magentaBtn
            // 
            this.magentaBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.magentaBtn.BackgroundImage = global::mise_en_page_MM.Properties.Resources.magenta;
            this.magentaBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.magentaBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.magentaBtn.FlatAppearance.BorderSize = 0;
            this.magentaBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.magentaBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.magentaBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.magentaBtn.Location = new System.Drawing.Point(14, 310);
            this.magentaBtn.Name = "magentaBtn";
            this.magentaBtn.Size = new System.Drawing.Size(40, 40);
            this.magentaBtn.TabIndex = 0;
            this.magentaBtn.UseVisualStyleBackColor = true;
            this.magentaBtn.Click += new System.EventHandler(this.Bouton_Click);
            this.magentaBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseDown);
            this.magentaBtn.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseUp);
            // 
            // cyanBtn
            // 
            this.cyanBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cyanBtn.BackgroundImage = global::mise_en_page_MM.Properties.Resources.cyan;
            this.cyanBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cyanBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cyanBtn.FlatAppearance.BorderSize = 0;
            this.cyanBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.cyanBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.cyanBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cyanBtn.Location = new System.Drawing.Point(14, 371);
            this.cyanBtn.Name = "cyanBtn";
            this.cyanBtn.Size = new System.Drawing.Size(40, 40);
            this.cyanBtn.TabIndex = 0;
            this.cyanBtn.UseVisualStyleBackColor = true;
            this.cyanBtn.Click += new System.EventHandler(this.Bouton_Click);
            this.cyanBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseDown);
            this.cyanBtn.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Bouton_MouseUp);
            // 
            // Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = global::mise_en_page_MM.Properties.Resources.layout;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(474, 735);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Game";
            this.Text = "MasterMind - Game";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Menu_FormClosing);
            this.Load += new System.EventHandler(this.Game_Load);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button greenBtn;
        private System.Windows.Forms.Button yellowBtn;
        private System.Windows.Forms.Button whiteBtn;
        private System.Windows.Forms.Button redBtn;
        private System.Windows.Forms.Button blueBtn;
        private System.Windows.Forms.Button magentaBtn;
        private System.Windows.Forms.Button cyanBtn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button menuBtn;
        private System.Windows.Forms.Button undoBtn;
        private System.Windows.Forms.Button resetBtn;
        private System.Windows.Forms.Button validBtn;
        private System.Windows.Forms.TableLayoutPanel colorPnl;
    }
}

