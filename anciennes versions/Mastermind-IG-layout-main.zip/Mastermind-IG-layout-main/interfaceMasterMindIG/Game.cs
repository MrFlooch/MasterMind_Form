﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mise_en_page_MM
{
    public partial class Game : Form
    {
        public Game()
        {
            InitializeComponent();
        }

        //compteur de taille du code
        int currentColumn;
        int currentLine;


        /// <summary>
        /// fait apparaitre les pions de couleurs sur le plateau
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        int indexCurrentButton = 0;

        private void Game_Load(object sender, EventArgs e)
        {
            gridInitialise();
        }

        //initialise le tableau ou sera les couleurs
        Button[,] colorBtnGrid;

        //donne la taille des ligne et des colonnes du tableau
        const int ROWS = 4;
        const int COLUMNS = 10;

        private List<Button> currentButton = new List<Button>();
        private List<Button> secretCode = new List<Button>();
        private List<Button> history = new List<Button>();

        /// <summary>
        /// change la taill du bouton de couleur lors du clic
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Bouton_MouseDown(object sender, MouseEventArgs e)
        {
            Button bouton = (Button)sender;
            AdjustButtonSize(bouton, -5);
        }

        private void Bouton_MouseUp(object sender, MouseEventArgs e)
        {
            Button bouton = (Button)sender;
            AdjustButtonSize(bouton, 5);
        }

        /// <summary>
        /// fait apparaitre les boutons au demmarage
        /// </summary>
        private void gridInitialise()
        {
            colorBtnGrid = new Button[ROWS, COLUMNS];
            int count = 0;

            //création des boutons
            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < COLUMNS; j++)
                {
                    Button bouton = new Button();

                    //text du bouton
                    bouton.Text = count.ToString();

                    //utilise la même taille que le premier bouton
                    bouton.Size = new System.Drawing.Size(35, 35);

                    //change le style des bouttons
                    bouton.FlatStyle = FlatStyle.Flat;
                    bouton.FlatAppearance.BorderSize = 0;
                    bouton.BackgroundImage = Properties.Resources.trou;
                    bouton.FlatAppearance.MouseOverBackColor = Color.Transparent;
                    bouton.Anchor = AnchorStyles.None;

                    //ajoute un nouveau bouton
                    colorPnl.Controls.Add(bouton);

                    colorBtnGrid[i, j] = bouton;

                    count++;
                }
            }
        }

        /// <summary>
        /// animation lorsque qu'on clic sur un bouton de couleur
        /// </summary>
        /// <param name="bouton"></param>
        /// <param name="adjustment"></param>
        private void AdjustButtonSize(Button bouton, int adjustment)
        {
            bouton.Size = new Size(bouton.Width + adjustment, bouton.Height + adjustment);
        }

        /// <summary>
        /// cliquer sur le bouton change les autre boutons
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Bouton_Click(object sender, EventArgs e)
        {
            Button colorButton = (Button)sender;

            if (currentColumn < 4)
            {
                colorBtnGrid[currentLine, currentColumn].BackgroundImage = colorButton.BackgroundImage;

                // Ajoutez le bouton à l'historique
                history.Add(colorButton);

                // Ajoute le bouton cliqué à la séquence actuelle
                Button colorBtn = (Button)sender;
                currentButton.Add(colorBtn);

                // Vérifie si la séquence est plus longue que le code secret
                if (currentButton.Count > secretCode.Count)
                {
                    // Réinitialise la séquence actuelle si elle dépasse la longueur du code secret
                    currentButton.Clear();
                }

                // Ajoutez le bouton à l'historique
                history.Add((Button)sender);

                currentColumn++;
            }

            else
            {
                //montre un message d'erreur quand la limite du code est dépassée
                MessageBox.Show("4 couleurs max","Attention", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
                    

        private void undoBtn_Click(object sender, EventArgs e)
        {
            if (history.Count > 0)
            {
                // Obtenez le dernier bouton ajouté
                Button lastAddedButton = history.Last();

                // Retirez le dernier bouton ajouté
                history.Remove(lastAddedButton);

                // Réinitialisez l'index si nécessaire
                indexCurrentButton = Math.Max(0, indexCurrentButton - 1);

                // Efface le dernier bouton
                colorBtnGrid[currentLine,currentColumn].BackgroundImage = Properties.Resources.trou;

                //remet la taille du code par rapport au retour en arrière
                currentColumn--;
            }
        }

        private void validBtn_Click(object sender, EventArgs e)
        {
            //remet le compteur de couleurs à zero
            currentLine++;
            currentColumn = 0;
        }

        /// <summary>
        /// ferme l'application quand on appuye sur le bouton rouge de navigation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
