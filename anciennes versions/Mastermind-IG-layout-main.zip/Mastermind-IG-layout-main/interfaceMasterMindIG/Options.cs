﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace interfaceMasterMindIG
{
    public partial class Options : Form
    {
        Menu mainMenu;
        public Options(Menu menu)
        {
            InitializeComponent();

            //définit la position initialle de la fénètre
            this.StartPosition = FormStartPosition.CenterScreen;

            mainMenu = menu;
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            //ferme le fenètre actuelle
            this.Hide();
            mainMenu.Show();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void menuBtn_Click(object sender, EventArgs e)
        {
            //ferme le fenètre actuelle
            this.Hide();
            mainMenu.Show();
        }

        private void Menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
