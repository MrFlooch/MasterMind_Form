﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;
using Button = System.Windows.Forms.Button;

namespace interfaceMasterMindIG
{
    public partial class Game : Form
    {
        #region Variables
        //définit la longueur ddu code
        public int initCodeLength;
        //définit le nombre de couleurs dans le code
        public int initColorLength;

        private Difficulty difficulty;
        private Menu mainMenu;
        //compteur de taille du code
        int currentColumn;
        int currentLine;

        //donne la taille des ligne et des colonnes du tableau
        const int ROWS = 10;

        //initialise les grille à afficher
        Label[,] colorBtnGrid;  
        Label[,] hintBtnGrid;
        Label[] colorsSecretCode;
        Button[] colorBtnInit;

        //tableau des couleurs
        private Color[] codeColors = new Color[]
            {
                Color.Green, Color.Yellow, Color.White, Color.Red, Color.Blue, Color.Magenta, Color.Cyan
            };

        //tableau des images de fond
        private Image[] colorsImage = new Image[]
        {
            Properties.Resources.green, Properties.Resources.yellow, Properties.Resources.white, Properties.Resources.red, Properties.Resources.blue, Properties.Resources.magenta, Properties.Resources.cyan,
        };
        private Options options;
        #endregion

        #region Initialisation
        public Game(Menu menu, Difficulty difficulty)
        {
            InitializeComponent();

            this.difficulty = difficulty;
            initCodeLength = difficulty.codeLength;
            initColorLength = difficulty.colorLength;

            colorsSecretCode = new Label[initCodeLength];

            //génère le code
            generateCode();

            codePnl.Hide();

            //définit la position initialle de la fénètre
            this.StartPosition = FormStartPosition.CenterScreen;

            //empeche d'appuyer sur la bouton valider avant d'avoir le code complétment entré
            validBtn.Enabled = false;

            mainMenu = menu;
        }

        public Game(Options options)
        {
            this.options = options;
        }

        /// <summary>
        /// methode pour ajuster la taille de la fenêtre selon la taille du code
        /// </summary>
        /// <param name="codeLength"></param>
        private void AdjustLayoutBasedOnCodeLength(int codeLength)
        {
            int baseWidth = 500;
            int additionalWidth = (codeLength - 4);

            this.Size = new Size(baseWidth + additionalWidth * 80, 800);
            menuBtnPnl.Location = new Point((baseWidth + additionalWidth * 80) - 240, 635);
            colorPnl.Size = new Size(200 + additionalWidth * 50, 580);
            hintPnl.Size = new Size(125 + additionalWidth * 30, 580);
            hintPnl.Location = new Point(231 + additionalWidth * 50, 20);
            backgrounImagePnl.Size = new Size(460 + additionalWidth * 80, 735);
            colorBtnPnl.Location = new Point(380 + additionalWidth * 80, 25);
            gridPnl.Size = new Size(350 + additionalWidth * 80, 670);
        }
        private void Game_Load(object sender, EventArgs e)
        {
            //ajuste la taille des panel selon la longueur du code
            AdjustLayoutBasedOnCodeLength(initCodeLength);

            colorBtnGrid = new Label[ROWS, initCodeLength];
            hintBtnGrid = new Label[ROWS, initCodeLength];

            colorGridInitialize();
            hintGridInitialize();
            colorBtnInitialize();
        }

        /// <summary>
        /// initilaise la grille des boutons
        /// </summary>
        private void colorBtnInitialize()
        {
            colorBtnInit = new Button[initColorLength];

            for(int i = 0; i < initColorLength; i++)
            {
                Button colorButton = new Button();

                Color buttonColors = codeColors[i];
                Image imageColors = colorsImage[i];

                colorButton.Size = new System.Drawing.Size(40, 40);

                colorButton.Click += Bouton_Click;
                colorButton.MouseDown += Bouton_MouseDown;
                colorButton.MouseUp += Bouton_MouseUp;
                colorButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
                colorButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
                colorButton.FlatAppearance.CheckedBackColor = Color.Transparent;

                colorButton.Cursor = Cursors.Hand;
                colorButton.FlatStyle = FlatStyle.Flat;
                colorButton.BackColor = codeColors[i];
                colorButton.FlatAppearance.BorderSize = 0;
                colorButton.BackgroundImage = colorsImage[i];
                colorButton.BackgroundImageLayout = ImageLayout.Stretch;
                colorButton.Anchor = AnchorStyles.None;

                System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
                path.AddEllipse(0, 0, colorButton.Width - 1, colorButton.Height - 1);
                colorButton.Region = new Region(path);

                colorBtnPnl.Controls.Add(colorButton);

                colorBtnInit[i] = colorButton;
            }
        }

        /// <summary>
        /// fait apparaitre les boutons au demmarage
        /// </summary>
        private void colorGridInitialize()
        {
            colorBtnGrid = new Label[ROWS, initCodeLength];

            //création des boutons pour les couleurs
            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < initCodeLength; j++)
                {
                    Label guessButton = new Label();

                    //utilise la même taille que le premier bouton
                    guessButton.Size = new Size(35, 35);

                    //change le style des bouttons
                    guessButton.FlatStyle = FlatStyle.Flat;
                    guessButton.BackColor = Color.Transparent;
                    guessButton.Location = new Point (j * 50, i * 60);
                    guessButton.BackgroundImage = Properties.Resources.trou;
                    guessButton.BackgroundImageLayout = ImageLayout.Stretch;
                    guessButton.Enabled = false;
                    guessButton.Anchor = AnchorStyles.None;

                    System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
                    path.AddEllipse(0, 0, guessButton.Width - 1, guessButton.Height - 1);
                    guessButton.Region = new Region(path);

                    //ajoute un nouveau bouton
                    colorPnl.Controls.Add(guessButton);

                    colorBtnGrid[i, j] = guessButton;
                }
            }
        }

        private void hintGridInitialize()
        {
            //création des boutons pour les indices
            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < initCodeLength; j++)
                {
                    Label hintButton = new Label();

                    //utilise la même taille que le premier bouton
                    hintButton.Size = new System.Drawing.Size(20, 20);

                    //change le style des bouttons
                    hintButton.FlatStyle = FlatStyle.Flat;
                    hintButton.Location = new Point(j * 30, i * 60);
                    hintButton.BackColor = Color.Transparent;
                    hintButton.BackgroundImage = Properties.Resources.petitTrou;
                    hintButton.Enabled = false;
                    hintButton.Anchor = AnchorStyles.None;

                    //ajoute un nouveau bouton
                    hintPnl.Controls.Add(hintButton);

                    //associe le bouton au tableau
                    hintBtnGrid[i, j] = hintButton;
                }
            }
        }

        private void generateCode()
        {
            Random random = new Random();

            //génère le code
            for (int i = 0; i < initCodeLength; i++)
            {
                Color randomCodeButton = codeColors[random.Next(initColorLength)];
                //Image imageColors = colorsImage[i];

                Label secretCode = new Label();

                secretCode.Size = new Size(35, 35);
                secretCode.BackColor = randomCodeButton;
                secretCode.Location = new Point (i * 50);
                secretCode.Enabled = false;
                secretCode.FlatStyle = FlatStyle.Flat;

                //trouver un moyen de faire correspondre la couleur et l'image
                //secretCode.BackgroundImage = colorsImage[i];

                secretCode.Anchor = AnchorStyles.None;

                System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
                path.AddEllipse(0, 0, secretCode.Width - 1, secretCode.Height - 1);
                secretCode.Region = new Region(path);

                //ajoute les boutons dans la grille
                codePnl.Controls.Add(secretCode);

                //associe le tableau au code secret
                colorsSecretCode[i] = secretCode;
            }
        }


        #endregion

        #region Animation

        /// <summary>
        /// change la taille du bouton de couleur lors du clic
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Bouton_MouseDown(object sender, MouseEventArgs e)
        {
            Button bouton = (Button)sender;
            AdjustButtonSize(bouton, -5);
        }

        private void Bouton_MouseUp(object sender, MouseEventArgs e)
        {
            Button bouton = (Button)sender;
            AdjustButtonSize(bouton, 5);

        }

        /// <summary>
        /// animation lorsque qu'on clic sur un bouton de couleur
        /// </summary>
        /// <param name="bouton"></param>
        /// <param name="adjustment"></param>
        private void AdjustButtonSize(Button bouton, int adjustment)
        {
            bouton.Size = new Size(bouton.Width + adjustment, bouton.Height + adjustment);
        }
        #endregion

        #region Vérification

        /// <summary>
        /// cliquer sur le bouton change les autre boutons
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Bouton_Click(object sender, EventArgs e)
        {
            Button colorButton = (Button)sender;

            //affiche le bouton cliqué sur la grille
            if (currentColumn < initCodeLength)
            {
                colorBtnGrid[currentLine, currentColumn].BackColor = colorButton.BackColor;
                colorBtnGrid[currentLine, currentColumn].BackgroundImage = colorButton.BackgroundImage;

                currentColumn++;
            }

            else
            {
                //montre un message d'erreur quand la limite du code est dépassée
                MessageBox.Show($"{initCodeLength} couleurs max", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (currentLine == 11)
            {
                MessageBox.Show($"Désolé, vous avez perdu.");
                codePnl.Show();
            }

            //active le bouton valider
            if (currentColumn == initCodeLength)
            {
                validBtn.Enabled = true;
            }

            else
            {
                validBtn.Enabled = false;
            }
        }

        private void undoBtn_Click(object sender, EventArgs e)
        {
            if (currentColumn > 0)
            {
                //remet la taille du code par rapport au retour en arrière
                currentColumn--;

                // Efface le dernier bouton
                colorBtnGrid[currentLine, currentColumn].BackColor = Color.Transparent;
                colorBtnGrid[currentLine, currentColumn].BackgroundImage = Properties.Resources.trou;
            }
        }

        /// <summary>
        /// valide le code donné par l'utilisateur
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void validBtn_Click(object sender, EventArgs e)
        {
            checkCode();
            //remet le compteur de couleurs à zero
            currentColumn = 0;
            currentLine++;

            validBtn.Enabled = false;
        }

        /// <summary>
        /// vérifie le code
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void checkCode()
        {
            // Vérifie les couleurs du code
            int rightPlace = 0;
            int rightColor = 0;

            // Tableau qui stocke le nombre d'occurrences de chaque couleur dans le code secret et dans l'input de l'utilisateur
            int[] secretColorCount = new int[codeColors.Length];
            int[] inputColorCount = new int[codeColors.Length];

            // Compte le nombre d'occurrences de chaque couleur dans le code secret
            for (int i = 0; i < initCodeLength; i++)
            {
                secretColorCount[Array.IndexOf(codeColors, colorsSecretCode[i].BackColor)]++;
            }

            // Compte le nombre d'occurrences de chaque couleur dans l'input de l'utilisateur
            for (int i = 0; i < initCodeLength; i++)
            {
                inputColorCount[Array.IndexOf(codeColors, colorBtnGrid[currentLine, i].BackColor)]++;
            }

            // Vérifie si la couleur est correcte à la position correspondante dans le code secret
            for (int i = 0; i < initCodeLength; i++)
            {
                if (colorBtnGrid[currentLine, i].BackColor == colorsSecretCode[i].BackColor)
                {
                    // Couleur correcte et bien placée
                    rightPlace++;
                }
            }

            // si le code correspond
            if(rightPlace == initCodeLength)
            {
                codePnl.Show();
                MessageBox.Show($"Bravo, vous avez gagné en {currentLine + 1} essais");
                
                resetAll();

                currentLine--;
            }

            else
            {
                // Couleurs correctes mais mal placées
                for (int i = 0; i < codeColors.Length; i++)
                {
                    rightColor += Math.Min(secretColorCount[i], inputColorCount[i]);
                }

                rightColor -= rightPlace;

                // Met les indices dans le tableau (petitTrou, littleWhite, littleBlack) en fonction des résultats
                for (int i = 0; i < initCodeLength; i++)
                {
                    if (i < rightPlace)
                    {
                        hintBtnGrid[currentLine, i].BackgroundImage = Properties.Resources.littleWhite;
                    }
                    else if (i >= rightPlace && i < rightPlace + rightColor)
                    {
                        hintBtnGrid[currentLine, i].BackgroundImage = Properties.Resources.littleBlack;
                    }
                    else
                    {
                        hintBtnGrid[currentLine, i].BackgroundImage = Properties.Resources.petitTrou;
                    }
                }

            }
        }

        #endregion

        #region Boutons
        /// <summary>
        /// renvoie au menu principale
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void menuBtn_Click(object sender, EventArgs e)
        {
            //ferme le fenètre actuelle
            this.Hide();
            mainMenu.Show();
        }

        private void resetAll()
        {
            currentColumn = 0;
            currentLine = 0;

            colorPnl.Controls.Clear();
            colorGridInitialize();

            hintPnl.Controls.Clear();
            hintGridInitialize();

            codePnl.Controls.Clear();
            generateCode();

            codePnl.Hide();
        }

        private void hideBtn_MouseDown(object sender, MouseEventArgs e)
        {
            codePnl.Show();
        }

        private void hideBtn_MouseUp(object sender, MouseEventArgs e)
        {
            codePnl.Hide();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            resetAll();
        }

        #endregion

        /// <summary>
        /// ferme l'application quand on appuye sur le bouton rouge de navigation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }


    }
}
