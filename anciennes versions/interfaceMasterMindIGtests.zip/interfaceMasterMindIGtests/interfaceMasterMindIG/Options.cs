﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace interfaceMasterMindIG
{
    public partial class Options : Form
    {
        Menu mainMenu;
        Label[] colorBtnGrid;

        public Options(Menu menu)
        {
            InitializeComponent();

            //définit la position initialle de la fénètre
            this.StartPosition = FormStartPosition.CenterScreen;

            mainMenu = menu;
        }

        int colorLength = 7;
        //tableau des couleurs
        private Color[] codeColors = new Color[]
            {
                Color.Green, Color.Yellow, Color.White, Color.Red, Color.Blue, Color.Magenta, Color.Cyan
            };

        //tableau des images de fond
        private Image[] colorsImage = new Image[]
        {
            Properties.Resources.green, Properties.Resources.yellow, Properties.Resources.white, Properties.Resources.red, Properties.Resources.blue, Properties.Resources.magenta, Properties.Resources.cyan, 
        };

        private Image[] ironColorsImage = new Image[]
        {
            Properties.Resources.irongreen, Properties.Resources.ironyellow, Properties.Resources.ironwhite, Properties.Resources.ironred, Properties.Resources.ironblue, Properties.Resources.ironmagenta, Properties.Resources.ironcyan,
        };

        private Image[] neonColorsImage = new Image[]
        {
            Properties.Resources.green_neon, Properties.Resources.yellow_neon, Properties.Resources.white_neon, Properties.Resources.red_neon, Properties.Resources.blue_neon, Properties.Resources.magenta_neon, Properties.Resources.cyan_neon,       
        };

        private Image[] pokerColorsImage = new Image[]
        {
            Properties.Resources.green_poker, Properties.Resources.yellow_poker, Properties.Resources.white_poker, Properties.Resources.red_poker, Properties.Resources.blue_poker, Properties.Resources.magenta_poker, Properties.Resources.cyan_poker,
        };

        private void Options_Load(object sender, EventArgs e)
        {
            colorBtnGrid = new Label[colorLength];
            colorBtnInitialize();
        }

        private void colorBtnInitialize()
        {
            colorBtnGrid = new Label[colorLength];

            for (int i = 0; i < colorLength; i++)
            {
                Label colorPnl = new Label();
                Color buttonColors = codeColors[i];
                Image imageColors = colorsImage[i];

                colorPnl.BackColor = codeColors[i];                
                colorPnl.Size = new System.Drawing.Size(50, 50);
                colorPnl.BackgroundImageLayout = ImageLayout.Stretch;
                colorPnl.Anchor = AnchorStyles.None;

                System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
                path.AddEllipse(0, 0, colorPnl.Width, colorPnl.Height);
                colorPnl.Region = new Region(path);

                colorLayoutPnl.Controls.Add(colorPnl);

                colorBtnGrid[i] = colorPnl;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void menuBtn_Click(object sender, EventArgs e)
        {
            //ferme le fenètre actuelle
            this.Hide();
            mainMenu.Show();
        }
        public void BackgroundBtn_Click(object sender, EventArgs e)
        {
            backgroungPnl.BackColor = SystemColors.ControlDarkDark;
            backgroungPnl.BackgroundImage = Properties.Resources.transparent;

            for (int i = 0; i < colorLength; i++)
            {
                colorBtnGrid[i].BackgroundImage = Properties.Resources.transparent;
                colorBtnGrid[i].BackColor = codeColors[i];
            }
        }
        public void woodBackgroundBtn_Click(object sender, EventArgs e)
        {
            backgroungPnl.BackgroundImage = Properties.Resources.wood;
            backgroungPnl.BackColor = System.Drawing.Color.Transparent;
            backgroungPnl.BackgroundImageLayout = ImageLayout.Stretch;

            //Game.panel1.BackgroundImage = Properties.Resources.wood;

            for (int i = 0; i < colorLength; i++)
            {
                colorBtnGrid[i].BackgroundImage = colorsImage[i];
                colorBtnGrid[i].BackColor = Color.Transparent;
            }
        }
        public void ironBackgroundBtn_Click(object sender, EventArgs e)
        {
            backgroungPnl.BackgroundImage = Properties.Resources.iron;
            backgroungPnl.BackColor = System.Drawing.Color.Transparent;
            backgroungPnl.BackgroundImageLayout = ImageLayout.Stretch;

            for (int i = 0; i < colorLength; i++)
            {
                colorBtnGrid[i].BackgroundImage = ironColorsImage[i];
                colorBtnGrid[i].BackColor = Color.Transparent;
            }
        }
        public void woolBackgroundBtn_Click(object sender, EventArgs e)
        {
            backgroungPnl.BackgroundImage = Properties.Resources.wool;
            backgroungPnl.BackColor = System.Drawing.Color.Transparent;
            backgroungPnl.BackgroundImageLayout = ImageLayout.Stretch;

            for (int i = 0; i < colorLength; i++)
            {
                colorBtnGrid[i].BackgroundImage = pokerColorsImage[i];
                colorBtnGrid[i].BackColor = Color.Transparent;
            }
        }
        public void neonBackgroundBtn_Click(object sender, EventArgs e)
        {
            backgroungPnl.BackColor = SystemColors.WindowText;
            backgroungPnl.BackgroundImage = Properties.Resources.transparent;

            for (int i = 0; i < colorLength; i++)
            {
                colorBtnGrid[i].BackgroundImage = neonColorsImage[i];
                colorBtnGrid[i].BackColor = Color.Transparent;
            }
        }
        private void Options_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
