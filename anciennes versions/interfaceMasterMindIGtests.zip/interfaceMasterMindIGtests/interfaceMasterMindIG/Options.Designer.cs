﻿namespace interfaceMasterMindIG
{
    partial class Options
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Options));
            this.backgroungPnl = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.FrenchBx = new System.Windows.Forms.CheckBox();
            this.EnglishBx = new System.Windows.Forms.CheckBox();
            this.italianBx = new System.Windows.Forms.CheckBox();
            this.GermanBx = new System.Windows.Forms.CheckBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.normalBackgroundBtn = new System.Windows.Forms.Button();
            this.woodBackgroundBtn = new System.Windows.Forms.Button();
            this.ironBackgroundBtn = new System.Windows.Forms.Button();
            this.woolBackgroundBtn = new System.Windows.Forms.Button();
            this.neonBackgroundBtn = new System.Windows.Forms.Button();
            this.optionTitle = new System.Windows.Forms.Label();
            this.optionTexte = new System.Windows.Forms.Label();
            this.menuBtn = new System.Windows.Forms.Button();
            this.colorLayoutPnl = new System.Windows.Forms.TableLayoutPanel();
            this.optionCheckBox = new System.Windows.Forms.CheckBox();
            this.backgroungPnl.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.colorLayoutPnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // backgroungPnl
            // 
            this.backgroungPnl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.backgroungPnl.BackColor = System.Drawing.Color.Gray;
            this.backgroungPnl.BackgroundImage = global::interfaceMasterMindIG.Properties.Resources.transparent;
            this.backgroungPnl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.backgroungPnl.ColumnCount = 3;
            this.backgroungPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.backgroungPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.backgroungPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.backgroungPnl.Controls.Add(this.flowLayoutPanel2, 1, 5);
            this.backgroungPnl.Controls.Add(this.flowLayoutPanel1, 1, 2);
            this.backgroungPnl.Controls.Add(this.optionTitle, 1, 1);
            this.backgroungPnl.Controls.Add(this.optionTexte, 1, 4);
            this.backgroungPnl.Controls.Add(this.menuBtn, 1, 6);
            this.backgroungPnl.Controls.Add(this.colorLayoutPnl, 1, 3);
            this.backgroungPnl.Location = new System.Drawing.Point(12, 12);
            this.backgroungPnl.Name = "backgroungPnl";
            this.backgroungPnl.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.backgroungPnl.RowCount = 8;
            this.backgroungPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.backgroungPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.backgroungPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21F));
            this.backgroungPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21F));
            this.backgroungPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.5F));
            this.backgroungPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.5F));
            this.backgroungPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.backgroungPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.backgroungPnl.Size = new System.Drawing.Size(776, 426);
            this.backgroungPnl.TabIndex = 3;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel2.Controls.Add(this.FrenchBx);
            this.flowLayoutPanel2.Controls.Add(this.EnglishBx);
            this.flowLayoutPanel2.Controls.Add(this.italianBx);
            this.flowLayoutPanel2.Controls.Add(this.GermanBx);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(41, 309);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(692, 38);
            this.flowLayoutPanel2.TabIndex = 4;
            // 
            // FrenchBx
            // 
            this.FrenchBx.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.FrenchBx.AutoSize = true;
            this.FrenchBx.Font = new System.Drawing.Font("Bahnschrift Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FrenchBx.Location = new System.Drawing.Point(3, 3);
            this.FrenchBx.Name = "FrenchBx";
            this.FrenchBx.Size = new System.Drawing.Size(110, 37);
            this.FrenchBx.TabIndex = 4;
            this.FrenchBx.Text = "Français";
            this.FrenchBx.UseVisualStyleBackColor = true;
            // 
            // EnglishBx
            // 
            this.EnglishBx.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnglishBx.AutoSize = true;
            this.EnglishBx.Font = new System.Drawing.Font("Bahnschrift Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnglishBx.Location = new System.Drawing.Point(119, 3);
            this.EnglishBx.Name = "EnglishBx";
            this.EnglishBx.Size = new System.Drawing.Size(98, 37);
            this.EnglishBx.TabIndex = 4;
            this.EnglishBx.Text = "English";
            this.EnglishBx.UseVisualStyleBackColor = true;
            // 
            // italianBx
            // 
            this.italianBx.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.italianBx.AutoSize = true;
            this.italianBx.Font = new System.Drawing.Font("Bahnschrift Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.italianBx.Location = new System.Drawing.Point(223, 3);
            this.italianBx.Name = "italianBx";
            this.italianBx.Size = new System.Drawing.Size(100, 37);
            this.italianBx.TabIndex = 4;
            this.italianBx.Text = "Italiano";
            this.italianBx.UseVisualStyleBackColor = true;
            // 
            // GermanBx
            // 
            this.GermanBx.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.GermanBx.AutoSize = true;
            this.GermanBx.Font = new System.Drawing.Font("Bahnschrift Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GermanBx.Location = new System.Drawing.Point(329, 3);
            this.GermanBx.Name = "GermanBx";
            this.GermanBx.Size = new System.Drawing.Size(96, 37);
            this.GermanBx.TabIndex = 4;
            this.GermanBx.Text = "Deutsh";
            this.GermanBx.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.normalBackgroundBtn);
            this.flowLayoutPanel1.Controls.Add(this.woodBackgroundBtn);
            this.flowLayoutPanel1.Controls.Add(this.ironBackgroundBtn);
            this.flowLayoutPanel1.Controls.Add(this.woolBackgroundBtn);
            this.flowLayoutPanel1.Controls.Add(this.neonBackgroundBtn);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(41, 87);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(692, 83);
            this.flowLayoutPanel1.TabIndex = 4;
            // 
            // normalBackgroundBtn
            // 
            this.normalBackgroundBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.normalBackgroundBtn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.normalBackgroundBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.normalBackgroundBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.normalBackgroundBtn.FlatAppearance.BorderSize = 3;
            this.normalBackgroundBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.normalBackgroundBtn.Font = new System.Drawing.Font("Bahnschrift Condensed", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.normalBackgroundBtn.ForeColor = System.Drawing.Color.White;
            this.normalBackgroundBtn.Location = new System.Drawing.Point(3, 3);
            this.normalBackgroundBtn.Name = "normalBackgroundBtn";
            this.normalBackgroundBtn.Size = new System.Drawing.Size(132, 75);
            this.normalBackgroundBtn.TabIndex = 7;
            this.normalBackgroundBtn.Text = "Classique";
            this.normalBackgroundBtn.UseVisualStyleBackColor = false;
            this.normalBackgroundBtn.Click += new System.EventHandler(this.BackgroundBtn_Click);
            // 
            // woodBackgroundBtn
            // 
            this.woodBackgroundBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.woodBackgroundBtn.BackgroundImage = global::interfaceMasterMindIG.Properties.Resources.woodBtn;
            this.woodBackgroundBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.woodBackgroundBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.woodBackgroundBtn.FlatAppearance.BorderSize = 3;
            this.woodBackgroundBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.woodBackgroundBtn.Font = new System.Drawing.Font("Bahnschrift Condensed", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.woodBackgroundBtn.ForeColor = System.Drawing.Color.Black;
            this.woodBackgroundBtn.Location = new System.Drawing.Point(141, 3);
            this.woodBackgroundBtn.Name = "woodBackgroundBtn";
            this.woodBackgroundBtn.Size = new System.Drawing.Size(132, 75);
            this.woodBackgroundBtn.TabIndex = 7;
            this.woodBackgroundBtn.Text = "Wood";
            this.woodBackgroundBtn.UseVisualStyleBackColor = true;
            this.woodBackgroundBtn.Click += new System.EventHandler(this.woodBackgroundBtn_Click);
            // 
            // ironBackgroundBtn
            // 
            this.ironBackgroundBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ironBackgroundBtn.BackgroundImage = global::interfaceMasterMindIG.Properties.Resources.ironBtn;
            this.ironBackgroundBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ironBackgroundBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.ironBackgroundBtn.FlatAppearance.BorderSize = 3;
            this.ironBackgroundBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ironBackgroundBtn.Font = new System.Drawing.Font("Bahnschrift Condensed", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ironBackgroundBtn.ForeColor = System.Drawing.Color.White;
            this.ironBackgroundBtn.Location = new System.Drawing.Point(279, 3);
            this.ironBackgroundBtn.Name = "ironBackgroundBtn";
            this.ironBackgroundBtn.Size = new System.Drawing.Size(132, 75);
            this.ironBackgroundBtn.TabIndex = 7;
            this.ironBackgroundBtn.Text = "Iron";
            this.ironBackgroundBtn.UseVisualStyleBackColor = true;
            this.ironBackgroundBtn.Click += new System.EventHandler(this.ironBackgroundBtn_Click);
            // 
            // woolBackgroundBtn
            // 
            this.woolBackgroundBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.woolBackgroundBtn.BackgroundImage = global::interfaceMasterMindIG.Properties.Resources.woolBtn;
            this.woolBackgroundBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.woolBackgroundBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.woolBackgroundBtn.FlatAppearance.BorderSize = 3;
            this.woolBackgroundBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.woolBackgroundBtn.Font = new System.Drawing.Font("Bahnschrift Condensed", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.woolBackgroundBtn.ForeColor = System.Drawing.Color.White;
            this.woolBackgroundBtn.Location = new System.Drawing.Point(417, 3);
            this.woolBackgroundBtn.Name = "woolBackgroundBtn";
            this.woolBackgroundBtn.Size = new System.Drawing.Size(132, 75);
            this.woolBackgroundBtn.TabIndex = 7;
            this.woolBackgroundBtn.Text = "Poker";
            this.woolBackgroundBtn.UseVisualStyleBackColor = true;
            this.woolBackgroundBtn.Click += new System.EventHandler(this.woolBackgroundBtn_Click);
            // 
            // neonBackgroundBtn
            // 
            this.neonBackgroundBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.neonBackgroundBtn.BackColor = System.Drawing.Color.Black;
            this.neonBackgroundBtn.BackgroundImage = global::interfaceMasterMindIG.Properties.Resources.neon;
            this.neonBackgroundBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.neonBackgroundBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.neonBackgroundBtn.FlatAppearance.BorderSize = 3;
            this.neonBackgroundBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.neonBackgroundBtn.Font = new System.Drawing.Font("Bahnschrift Condensed", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.neonBackgroundBtn.ForeColor = System.Drawing.Color.White;
            this.neonBackgroundBtn.Location = new System.Drawing.Point(555, 3);
            this.neonBackgroundBtn.Name = "neonBackgroundBtn";
            this.neonBackgroundBtn.Size = new System.Drawing.Size(132, 75);
            this.neonBackgroundBtn.TabIndex = 7;
            this.neonBackgroundBtn.Text = "Neon";
            this.neonBackgroundBtn.UseVisualStyleBackColor = false;
            this.neonBackgroundBtn.Click += new System.EventHandler(this.neonBackgroundBtn_Click);
            // 
            // optionTitle
            // 
            this.optionTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.optionTitle.AutoSize = true;
            this.optionTitle.Font = new System.Drawing.Font("Bahnschrift Condensed", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optionTitle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.optionTitle.Location = new System.Drawing.Point(327, 28);
            this.optionTitle.Name = "optionTitle";
            this.optionTitle.Size = new System.Drawing.Size(119, 48);
            this.optionTitle.TabIndex = 4;
            this.optionTitle.Text = "Options";
            // 
            // optionTexte
            // 
            this.optionTexte.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.optionTexte.AutoSize = true;
            this.optionTexte.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optionTexte.Location = new System.Drawing.Point(41, 272);
            this.optionTexte.Name = "optionTexte";
            this.optionTexte.Size = new System.Drawing.Size(56, 23);
            this.optionTexte.TabIndex = 5;
            this.optionTexte.Text = "Langue";
            // 
            // menuBtn
            // 
            this.menuBtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.menuBtn.AutoSize = true;
            this.menuBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menuBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuBtn.FlatAppearance.BorderSize = 3;
            this.menuBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menuBtn.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuBtn.ForeColor = System.Drawing.Color.White;
            this.menuBtn.Location = new System.Drawing.Point(624, 356);
            this.menuBtn.Name = "menuBtn";
            this.menuBtn.Size = new System.Drawing.Size(109, 39);
            this.menuBtn.TabIndex = 2;
            this.menuBtn.Text = "Menu";
            this.menuBtn.UseVisualStyleBackColor = true;
            this.menuBtn.Click += new System.EventHandler(this.menuBtn_Click);
            // 
            // colorLayoutPnl
            // 
            this.colorLayoutPnl.ColumnCount = 8;
            this.colorLayoutPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.colorLayoutPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.colorLayoutPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.colorLayoutPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.colorLayoutPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.colorLayoutPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.colorLayoutPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.colorLayoutPnl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.colorLayoutPnl.Controls.Add(this.optionCheckBox, 0, 0);
            this.colorLayoutPnl.Location = new System.Drawing.Point(41, 176);
            this.colorLayoutPnl.Name = "colorLayoutPnl";
            this.colorLayoutPnl.RowCount = 1;
            this.colorLayoutPnl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.colorLayoutPnl.Size = new System.Drawing.Size(692, 83);
            this.colorLayoutPnl.TabIndex = 4;
            // 
            // optionCheckBox
            // 
            this.optionCheckBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.optionCheckBox.AutoSize = true;
            this.optionCheckBox.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optionCheckBox.Location = new System.Drawing.Point(3, 28);
            this.optionCheckBox.Name = "optionCheckBox";
            this.optionCheckBox.Size = new System.Drawing.Size(99, 27);
            this.optionCheckBox.TabIndex = 6;
            this.optionCheckBox.Text = "Daltonisme";
            this.optionCheckBox.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.optionCheckBox.UseVisualStyleBackColor = true;
            this.optionCheckBox.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // Options
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.backgroungPnl);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Options";
            this.Text = "MasterMind - Options";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Options_FormClosing);
            this.Load += new System.EventHandler(this.Options_Load);
            this.backgroungPnl.ResumeLayout(false);
            this.backgroungPnl.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.colorLayoutPnl.ResumeLayout(false);
            this.colorLayoutPnl.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel backgroungPnl;
        private System.Windows.Forms.Button menuBtn;
        private System.Windows.Forms.Label optionTitle;
        private System.Windows.Forms.Label optionTexte;
        private System.Windows.Forms.CheckBox optionCheckBox;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button woodBackgroundBtn;
        private System.Windows.Forms.Button ironBackgroundBtn;
        private System.Windows.Forms.Button woolBackgroundBtn;
        private System.Windows.Forms.Button neonBackgroundBtn;
        private System.Windows.Forms.Button normalBackgroundBtn;
        private System.Windows.Forms.CheckBox FrenchBx;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.CheckBox EnglishBx;
        private System.Windows.Forms.CheckBox italianBx;
        private System.Windows.Forms.CheckBox GermanBx;
        private System.Windows.Forms.TableLayoutPanel colorLayoutPnl;
    }
}