﻿using interfaceMasterMindIG;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace interfaceMasterMindIG
{
    public partial class Difficulty : Form
    {

        public int codeLength = 4;
        public int colorLength = 7;

        private Menu mainMenu;
        public Difficulty(Menu menu)
        {
            InitializeComponent();

            // Définition des valeurs minimales et maximales de la TrackBar
            trackBarLength.Minimum = 3;
            trackBarLength.Maximum = 8;

            trackBarColors.Minimum = 2;
            trackBarColors.Maximum = 7;

            mainMenu = menu;

            //centre la page par rapport à l'écran
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void validBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Game game = new Game(mainMenu, this);
            game.initCodeLength = codeLength; //transmet les valeurs dans Game
            game.Show();
        }

        private void trackBarLength_Scroll(object sender, EventArgs e)
        {
            codeLength = trackBarLength.Value;
        }

        private void trackBarColors_Scroll(object sender, EventArgs e)
        {
            colorLength = trackBarColors.Value;
        }
    }
}
