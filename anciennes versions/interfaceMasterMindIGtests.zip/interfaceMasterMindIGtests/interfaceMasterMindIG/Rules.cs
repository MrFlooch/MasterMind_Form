﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace interfaceMasterMindIG
{
    public partial class Rules : Form
    {
        Menu mainMenu;
        public Rules(Menu menu)
        {
            InitializeComponent();

            //définit la position initialle de la fénètre
            this.StartPosition = FormStartPosition.CenterScreen;

            mainMenu = menu;
        }

        private void menuBtn_Click(object sender, EventArgs e)
        {
            //ferme le fenètre actuelle
            this.Hide();
            mainMenu.Show();
        }

        private void Menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
