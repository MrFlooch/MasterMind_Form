﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace interfaceMasterMindIG
{
    public partial class Menu : Form
    {
        Rules rules;
        Options options;
        public Menu()
        {
            InitializeComponent();
            rules = new Rules(this);
            options = new Options(this);

            //définit la position initialle de la fénètre
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        /// <summary>
        /// permet de quitter l'application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void quitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// permet d'acceder aux règles
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rulesBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            rules.Show();
        }

        /// <summary>
        /// permet d'acceder aux options
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void optionBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            options.Show();
        }

        /// <summary>
        /// permet d'acceder au jeu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void playBtn_Click(object sender, EventArgs e)
        {
            Difficulty difficulty = new Difficulty(this);
            difficulty.Show();
        }

        private void Menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
